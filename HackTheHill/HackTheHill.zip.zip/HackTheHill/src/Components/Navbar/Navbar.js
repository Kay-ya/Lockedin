// Import necessary modules from React
import React from 'react';
import './Navbar.css'; // Import CSS for Navbar styling

// Define the Navbar component
const Navbar = () => {
    return (
        <nav>
            <ul>
                <li><a href="/HackTheHill/public">Home</a></li>
                <li><a href="/ChatBox">ChatBox</a></li>
                {/*<li><a href="/Login"></a></li>*/}
            </ul>
        </nav>
    );
};

export default Navbar;
